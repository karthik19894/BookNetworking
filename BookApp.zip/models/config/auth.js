facebook_login={
    'facebookAuth':{
        'clientID':'249606868923189',
        'clientSecret':'793231727e62eca4b8d9c8e5ba407ef6',
        'callbackURL':'auth/facebook/callback'
    }
}

module.exports=facebook_login;